-- Customer portal v1.1 — Order AC Filters + Edit Personal Info
-- Additive only. Safe alongside existing staff org_access policies.

-- 1) Let a signed-in customer read the filters recorded for their own properties
drop policy if exists customer_read on public.property_filters;
create policy customer_read on public.property_filters
  for select to authenticated
  using (
    property_id in (
      select id from public.properties
      where customer_id = current_customer_id()
         or bill_to_customer_id = current_customer_id()
    )
  );

-- 2) Allow 'filter_order' as a request type so filter reorders land in the same inbox
alter table public.customer_requests
  drop constraint if exists customer_requests_request_type_check;
alter table public.customer_requests
  add constraint customer_requests_request_type_check
  check (request_type in ('pm','repair','system_quote','duct_cleaning','filter_order','other'));

-- 3) Safe, whitelisted self-service contact edit (own row only; identity/billing fields excluded)
create or replace function public.update_customer_contact(
  p_primary_phone   text,
  p_secondary_phone text,
  p_email_1         text,
  p_email_2         text,
  p_spouse_name     text
) returns void
language plpgsql security definer set search_path = public as $$
declare cid uuid;
begin
  cid := current_customer_id();
  if cid is null then
    raise exception 'not a portal customer';
  end if;
  update public.customers set
    primary_phone   = nullif(btrim(p_primary_phone),''),
    secondary_phone = nullif(btrim(p_secondary_phone),''),
    email_1         = coalesce(nullif(btrim(p_email_1),''), email_1),  -- never blank the login-match email
    email_2         = nullif(btrim(p_email_2),''),
    spouse_name     = nullif(btrim(p_spouse_name),'')
  where id = cid;
end$$;

revoke all on function public.update_customer_contact(text,text,text,text,text) from public;
grant execute on function public.update_customer_contact(text,text,text,text,text) to authenticated;
