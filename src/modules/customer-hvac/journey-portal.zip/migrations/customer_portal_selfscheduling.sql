-- Customer portal — self-scheduling gateway
-- Window model (AM/PM), office still assigns the tech. Availability is resolved
-- from org business_hours + org_holidays; capacity is a hard 4/day on self-bookings.
-- Same-day allowed (today's past windows are dropped). All checks re-run at booking
-- time under an advisory lock so two customers can't grab the same last slot.

alter table public.customer_requests
  add column if not exists scheduled_date date,
  add column if not exists scheduled_window text;

-- Resolve a single date's hours for an org: holiday overrides first, else weekday.
create or replace function public.booking_hours_for_date(p_org uuid, p_date date)
returns table(is_closed boolean, open_t time, close_t time)
language plpgsql stable security definer set search_path = public as $$
declare
  h jsonb; wd int := extract(dow from p_date)::int; key text;
  hol record; nth int; is_last boolean;
begin
  nth := ((extract(day from p_date)::int - 1) / 7) + 1;
  is_last := (extract(month from (p_date + interval '7 days'))::int <> extract(month from p_date)::int);
  select * into hol from org_holidays oh
    where oh.org_id = p_org
      and oh.month = extract(month from p_date)::int
      and (
        (oh.day is not null and oh.day = extract(day from p_date)::int)
        or (oh.week is not null and oh.weekday is not null and oh.weekday = wd
            and ((oh.week > 0 and oh.week = nth) or (oh.week = -1 and is_last)))
      )
    limit 1;
  if found then
    if hol.is_closed then return query select true, null::time, null::time;
    else return query select false, hol.open_time, hol.close_time; end if;
    return;
  end if;
  select business_hours into h from organizations where id = p_org;
  key := case wd when 0 then 'sun' when 1 then 'mon' when 2 then 'tue' when 3 then 'wed'
                 when 4 then 'thu' when 5 then 'fri' when 6 then 'sat' end;
  if h is null or h->key is null or (h->key->>'closed')::boolean then
    return query select true, null::time, null::time; return;
  end if;
  return query select false, (h->key->>'open')::time, (h->key->>'close')::time;
end$$;

-- Days a customer can actually book in the next p_days: open, not full, window not past.
create or replace function public.get_booking_availability(p_days int default 21)
returns table(d date, am_ok boolean, pm_ok boolean)
language plpgsql stable security definer set search_path = public as $$
declare
  cid uuid := current_customer_id(); org uuid;
  today date := (timezone('America/New_York', now()))::date;
  now_t time := (timezone('America/New_York', now()))::time;
  i int; cur date; hh record; booked int; a boolean; p boolean;
begin
  if cid is null then return; end if;
  select org_id into org from customers where id = cid;
  for i in 0..greatest(p_days-1,0) loop
    cur := today + i;
    select * into hh from booking_hours_for_date(org, cur);
    if hh.is_closed then continue; end if;
    select count(*) into booked from customer_requests
      where org_id = org and scheduled_date = cur and status not in ('cancelled','declined');
    if booked >= 4 then continue; end if;
    a := (hh.open_t < time '12:00');
    p := (hh.close_t > time '12:00');
    if cur = today then
      a := a and (now_t < time '12:00');
      p := p and (now_t < hh.close_t);
    end if;
    if a or p then d := cur; am_ok := a; pm_ok := p; return next; end if;
  end loop;
end$$;

-- Atomically book one self-scheduled appointment.
create or replace function public.book_appointment(
  p_property_id uuid, p_type text, p_date date, p_window text, p_details text)
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  cid uuid := current_customer_id(); org uuid;
  today date := (timezone('America/New_York', now()))::date;
  now_t time := (timezone('America/New_York', now()))::time;
  hh record; booked int; new_id uuid;
begin
  if cid is null then raise exception 'not a portal customer'; end if;
  if p_type not in ('pm','repair','system_quote','duct_cleaning') then raise exception 'job type not self-schedulable'; end if;
  if p_window not in ('am','pm') then raise exception 'invalid window'; end if;
  select org_id into org from customers where id = cid;
  if not exists (select 1 from properties where id = p_property_id and (customer_id = cid or bill_to_customer_id = cid)) then
    raise exception 'property not found';
  end if;
  if p_date < today then raise exception 'that date has passed'; end if;
  perform pg_advisory_xact_lock(hashtextextended(org::text || ':' || p_date::text, 0));
  select * into hh from booking_hours_for_date(org, p_date);
  if hh.is_closed then raise exception 'we are closed that day'; end if;
  if p_window = 'am' and not (hh.open_t < time '12:00') then raise exception 'no morning window that day'; end if;
  if p_window = 'pm' and not (hh.close_t > time '12:00') then raise exception 'no afternoon window that day'; end if;
  if p_date = today then
    if p_window = 'am' and now_t >= time '12:00' then raise exception 'the morning window has passed'; end if;
    if p_window = 'pm' and now_t >= hh.close_t then raise exception 'today is no longer bookable'; end if;
  end if;
  select count(*) into booked from customer_requests
    where org_id = org and scheduled_date = p_date and status not in ('cancelled','declined');
  if booked >= 4 then raise exception 'that day is fully booked'; end if;
  insert into customer_requests(org_id, customer_id, property_id, request_type, details,
                                preferred_window, scheduled_date, scheduled_window, status)
    values (org, cid, p_property_id, p_type, p_details, p_window, p_date, p_window, 'scheduled')
    returning id into new_id;
  return new_id;
end$$;

revoke all on function public.booking_hours_for_date(uuid,date) from public;
revoke all on function public.get_booking_availability(int) from public;
revoke all on function public.book_appointment(uuid,text,date,text,text) from public;
grant execute on function public.get_booking_availability(int) to authenticated;
grant execute on function public.book_appointment(uuid,text,date,text,text) to authenticated;
