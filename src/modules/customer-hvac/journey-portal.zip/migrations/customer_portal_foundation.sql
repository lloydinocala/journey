-- ============================================================================
-- Customer Portal — access foundation
-- Additive + SELECT-only. Adds a customer identity link, resolver, and
-- per-customer read policies that sit ALONGSIDE the existing org_access
-- policies. Staff access is untouched: a portal customer has no `users` row,
-- so is_super_admin()/current_org_id() return null/false for them and the
-- existing org_access policies grant them nothing. Customers get SELECT on
-- exactly their own rows; all writes go through the SECURITY DEFINER RPCs below.
-- ============================================================================

-- 1) Link a customer record to a Supabase auth user (set on first login).
alter table public.customers
  add column if not exists auth_user_id uuid references auth.users(id);
create unique index if not exists customers_auth_user_id_key
  on public.customers(auth_user_id) where auth_user_id is not null;

-- 2) Resolver: the customer_id for the current auth user (null for staff/anon).
--    SECURITY DEFINER so it can read customers without tripping RLS recursion.
create or replace function public.current_customer_id()
returns uuid language sql stable security definer set search_path = public as $$
  select id from public.customers where auth_user_id = auth.uid() limit 1
$$;
grant execute on function public.current_customer_id() to authenticated, anon;

-- 3) First-login link: bind auth.uid() to the customer with the SAME verified
--    email. OTP proves email ownership, so email-match linking is safe.
create or replace function public.claim_customer_portal()
returns uuid language plpgsql security definer set search_path = public as $$
declare cid uuid; em text;
begin
  select id into cid from public.customers where auth_user_id = auth.uid() limit 1;
  if cid is not null then return cid; end if;

  em := lower(coalesce(auth.jwt() ->> 'email',''));
  if em = '' then return null; end if;

  update public.customers set auth_user_id = auth.uid()
   where id = (
     select id from public.customers
      where auth_user_id is null
        and (lower(email_1) = em or lower(email_2) = em)
      order by created_at desc limit 1
   )
  returning id into cid;
  return cid;
end $$;
grant execute on function public.claim_customer_portal() to authenticated;

-- 4) Per-customer SELECT policies (additive; named customer_read).
create policy customer_read on public.customers
  for select to authenticated using (id = current_customer_id());

create policy customer_read on public.properties
  for select to authenticated
  using (customer_id = current_customer_id() or bill_to_customer_id = current_customer_id());

create policy customer_read on public.jobs
  for select to authenticated using (customer_id = current_customer_id());

create policy customer_read on public.invoices
  for select to authenticated
  using (
    bills_to_customer_id = current_customer_id()
    or property_id in (select id from public.properties)  -- RLS-filtered to theirs
  );

create policy customer_read on public.invoice_line_items
  for select to authenticated
  using (invoice_id in (select id from public.invoices));  -- RLS-filtered to theirs

create policy customer_read on public.maintenance_agreements
  for select to authenticated using (customer_id = current_customer_id());

create policy customer_read on public.maintenance_visits
  for select to authenticated using (customer_id = current_customer_id());

create policy customer_read on public.property_equipment
  for select to authenticated
  using (property_id in (select id from public.properties));

create policy customer_read on public.warranty_registrations
  for select to authenticated
  using (customer_id = current_customer_id()
         or property_id in (select id from public.properties));

-- the customer's own plan tier name (tiers are otherwise org-only config)
create policy customer_read on public.maintenance_agreement_tiers
  for select to authenticated
  using (id in (select tier_id from public.maintenance_agreements
                where customer_id = current_customer_id()));

-- 5) Service requests (the four "Schedule / Quote" tiles land here for the office).
create table if not exists public.customer_requests (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  customer_id uuid not null references public.customers(id),
  property_id uuid references public.properties(id),
  request_type text not null check (request_type in ('pm','repair','system_quote','duct_cleaning','other')),
  details text,
  preferred_window text,
  status text not null default 'new',
  created_at timestamptz not null default now(),
  handled_by uuid,
  handled_at timestamptz
);
alter table public.customer_requests enable row level security;

-- staff see/triage requests in their org; customer sees only their own.
create policy org_access on public.customer_requests
  for all to authenticated
  using (is_super_admin() or org_id = current_org_id())
  with check (is_super_admin() or org_id = current_org_id());
create policy customer_read on public.customer_requests
  for select to authenticated using (customer_id = current_customer_id());

-- customers submit via this RPC only (derives customer/org server-side; can't spoof).
create or replace function public.submit_customer_request(
  p_property_id uuid, p_type text, p_details text, p_window text)
returns uuid language plpgsql security definer set search_path = public as $$
declare cid uuid; oid uuid; rid uuid;
begin
  cid := current_customer_id();
  if cid is null then raise exception 'not a portal customer'; end if;
  if p_property_id is not null then
    select org_id into oid from public.properties
     where id = p_property_id and (customer_id = cid or bill_to_customer_id = cid);
    if oid is null then raise exception 'that property is not yours'; end if;
  else
    select org_id into oid from public.customers where id = cid;
  end if;
  insert into public.customer_requests(org_id, customer_id, property_id, request_type, details, preferred_window)
  values (oid, cid, p_property_id, p_type, nullif(p_details,''), nullif(p_window,''))
  returning id into rid;
  return rid;
end $$;
grant execute on function public.submit_customer_request(uuid,text,text,text) to authenticated;
